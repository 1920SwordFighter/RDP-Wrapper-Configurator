import os
from pathlib import Path
import subprocess
import requests
import io
import zipfile

current_path = Path(__file__).resolve().parent
parent_path = current_path.parent

OFFSETS = {
    "def": parent_path / "RDPOffsetFinder" / "RDPWrapOffsetFinder.exe",
    "nosym": parent_path / "RDPOffsetFinder" / "RDPWrapOffsetFinder_nosymbol.exe"
}

class DataHandler:
    def __init__(self, data_source):
        self.data_source = data_source

    def run_offset_finder(self, type="def"):
            path = OFFSETS.get(type)
            print(f"Targeting: {path}")
            
            if not path or not path.exists():
                return "Error: The .exe was not found in the RDPOffsetFinder folder."

            try:
                # Running the .exe and capturing the text output
                result = subprocess.run([str(path)], capture_output=True, text=True, check=True)
                return result.stdout
                
            except Exception as e:
                return f"An error occurred: {e}"
            
    def download_rdp_wrap(self, file_path=None):
        url = "https://github.com/stascorp/rdpwrap/releases/download/v1.6.2/RDPWrap-v1.6.2.zip"
        downloads_path = os.path.join(os.path.expanduser("~"), "Downloads")

        extract_to = os.path.join(downloads_path, "RDPWrapperSource")

        try:
            response = requests.get(url)
            response.raise_for_status()

            # 2. Extract the ZIP content
            with zipfile.ZipFile(io.BytesIO(response.content)) as z:
                z.extractall(extract_to)

            return z.namelist()  # Return list of extracted files for confirmation
        except requests.RequestException as e:
            return f"Failed to download RDPWrap: {e}"