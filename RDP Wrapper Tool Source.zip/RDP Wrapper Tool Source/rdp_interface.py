# Imports
import customtkinter as ctk

import handlers.data_handler as data_handler
import os
import sys
import ctypes
import threading
import subprocess

# RDP Interface GUI
data_handler_instance = data_handler.DataHandler("data_source_placeholder")

root = ctk.CTk()
root.title("RDPWrap Offset Finder")
root.geometry("600x400")

root.configure(padx=5, pady=10)
offset_text_box = ctk.CTkTextbox(root, width=500, height=200)

def restart_terminal_service():
    # 1. UI Feedback - Update textbox and disable button
    offset_text_box.delete("1.0", ctk.END)
    offset_text_box.insert(ctk.END, "Stopping Remote Desktop Services (TermService)...\n")
    restart_term_service.configure(state="disabled")

    def run_restart():
        # 2. Run the service management in a separate thread to avoid freezing the UI
        try:
            subprocess.run(["net", "stop", "TermService", "/y"], capture_output=True, check=True, creationflags=subprocess.CREATE_NO_WINDOW)
            root.after(0, lambda: offset_text_box.insert(ctk.END, "Starting Remote Desktop Services...\n"))

            subprocess.run(["net", "start", "TermService"], capture_output=True, check=True, creationflags=subprocess.CREATE_NO_WINDOW)
            root.after(0, lambda: finalize_ui("Success: TermService has been restarted!"))

        except subprocess.CalledProcessError as e:
            error_msg = f"Error: Failed to manage service.\n{e.stderr.decode() if e.stderr else e}"
            root.after(0, lambda: finalize_ui(error_msg))
        except Exception as e:
            root.after(0, lambda: finalize_ui(f"An unexpected error occurred: {e}"))

    def finalize_ui(message):
        # Clear and show final status, then re-enable the button
        offset_text_box.delete("1.0", ctk.END)
        offset_text_box.insert(ctk.END, message)
        restart_term_service.configure(state="normal")

    threading.Thread(target=run_restart, daemon=True).start()
            


def get_offset():
    # 1. Immediate UI Feedback (Main Thread)
    offset_text_box.delete("1.0", ctk.END)
    offset_text_box.insert(ctk.END, "Scanning for offsets... Please wait...")
    offset_finder_input.configure(state="disabled")  # Prevent spamming the button

    def run_search():
        try:
            mode = "nosym" if run_no_symbols_button.get() == 1 else "def"
            result = data_handler_instance.run_offset_finder(mode)
            
            # 3. Send data back to the UI (Safe hand-off)
            root.after(0, lambda: finalize_ui(result))
        except Exception as e:
            root.after(0, lambda: finalize_ui(f"Error during search: {e}"))

    def finalize_ui(result):
        # 4. Update the UI with the final result (Main Thread)
        offset_text_box.delete("1.0", ctk.END)
        offset_text_box.insert(ctk.END, result)
        offset_finder_input.configure(state="normal")
        print("Search complete.")

    threading.Thread(target=run_search, daemon=True).start()

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def append_to_config():
    if not offset_text_box.get("1.0", "end-1c").strip():
        offset_text_box.insert(ctk.END, "Nothing to write!")
        return
    
    content_to_append = offset_text_box.get("1.0", "end-1c").strip()
    
    if not content_to_append:
        print("Nothing to write!")
        return

    program_files = os.environ.get("ProgramFiles", "C:\\Program Files")
    config_path = os.path.join(program_files, "RDP Wrapper", "rdpwrap.ini")

    if not os.path.exists(config_path):
        offset_text_box.delete("1.0", ctk.END)
        offset_text_box.insert(ctk.END, f"Config file not found at {config_path}. Please ensure RDP Wrapper is installed.")
        return

    try:
        with open(config_path, "a") as f:
            f.write(f"\n\n\n{content_to_append}\n")
            
        offset_text_box.delete("1.0", ctk.END)
        offset_text_box.insert(ctk.END, "Successfully appended to rdpwrap.ini!")
        
    except PermissionError:
        offset_text_box.delete("1.0", ctk.END)
        offset_text_box.insert(ctk.END, "Permission denied. Please run as Administrator.")

        if not is_admin():
            script = os.path.abspath(sys.argv[0])
            params = " ".join(sys.argv[1:])
            ret = ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, f'"{script}" {params}', os.path.dirname(script), 1)

            if int(ret) > 32:
                sys.exit(0)
            else:
                print("Admin elevation failed or denied by user.")
                return False

    except Exception as e:
        print(f"An error occurred: {e}")

def install_rdp_wrap():
    # 1. Define the variables for the UI messages
    url = "https://github.com/stascorp/rdpwrap/releases/download/v1.6.2/RDPWrap-v1.6.2.zip"
    downloads_path = os.path.join(os.path.expanduser("~"), "Downloads", "RDPWrapperSource")

    # 2. Immediate UI Feedback
    offset_text_box.delete("1.0", ctk.END)
    offset_text_box.insert(ctk.END, f"Downloading RDP Wrapper from {url}..")
    install_rdpwrap_button.configure(state="disabled")

    def run_download():
        try:
            downloaded_files = data_handler_instance.download_rdp_wrap()
            
            if isinstance(downloaded_files, list):
                file_list_str = "\n- ".join(downloaded_files)
                success_message = (
                    f"Downloaded:\n- {file_list_str}\n\n"
                    f"Please check your downloads folder at:\n{downloads_path}"
                )
                root.after(0, lambda: finalize_ui(success_message))
            else:
                root.after(0, lambda: finalize_ui(downloaded_files))
                
        except Exception as e:
            root.after(0, lambda: finalize_ui(f"An unexpected error occurred: {e}"))

    def finalize_ui(message):
        # 5. Update the UI and re-enable the button
        offset_text_box.delete("1.0", ctk.END)
        offset_text_box.insert(ctk.END, message)
        install_rdpwrap_button.configure(state="normal")

    # Start the thread
    threading.Thread(target=run_download, daemon=True).start()

def clear_textbox():
    offset_text_box.delete("1.0", ctk.END)

root.grid_rowconfigure(0, weight=1)

# --- Grid Configuration ---
# 3 equal-width columns
root.grid_columnconfigure((0, 1, 2), weight=1, uniform="group1")

# Row 0 (Buttons) stays tight, Row 1 (Textbox) expands
root.grid_rowconfigure(0, weight=0)
root.grid_rowconfigure(1, weight=1)
root.grid_rowconfigure(2, weight=0)

# --- Row 0: The Buttons ---
# sticky="ew" ensures they all stretch to the same width
offset_finder_input = ctk.CTkButton(root, text="Run Offset Finder", command=get_offset)
offset_finder_input.grid(row=0, column=0, padx=(20, 5), pady=10, sticky="ew")

append_to_ini = ctk.CTkButton(root, text="Append to INI", command=append_to_config)
append_to_ini.grid(row=0, column=1, padx=5, pady=10, sticky="ew")

install_rdpwrap_button = ctk.CTkButton(root, text="Install RDPWrap", command=install_rdp_wrap)
install_rdpwrap_button.grid(row=0, column=2, padx=(5, 20), pady=10, sticky="ew")

# --- Row 1: The Textbox ---
# columnspan=3 makes it span the full width of the buttons above
offset_text_box.grid(row=1, column=0, columnspan=3, padx=20, pady=(0, 10), sticky="nsew")

# --- Row 2: The Checkbox ---
clear_textbox = ctk.CTkButton(root, text="Clear Textbox", command=lambda: offset_text_box.delete("1.0", ctk.END))
clear_textbox.grid(row=2, column=0, columnspan=2, padx=(155, 10), pady=(2, 10), sticky="w")

restart_term_service = ctk.CTkButton(root, text="Restart RDP Service", command=restart_terminal_service)
restart_term_service.grid(row=2, column=2, padx=(10, 20), pady=(2, 10), sticky="e")

run_no_symbols_button = ctk.CTkCheckBox(root, text="Run No Symbols")
run_no_symbols_button.grid(row=2, column=0, columnspan=3, padx=20, pady=(2, 10), sticky="w")

root.mainloop()